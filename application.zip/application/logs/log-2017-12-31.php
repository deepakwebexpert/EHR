<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-31 10:19:02 --> Severity: Notice --> Undefined property: Export::$ignore_directories C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Export.php 22
ERROR - 2017-12-31 10:19:02 --> Severity: Notice --> Only variables should be assigned by reference C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Export.php 28
