<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-04 01:20:30 --> 404 Page Not Found: Public/favicon.ico
