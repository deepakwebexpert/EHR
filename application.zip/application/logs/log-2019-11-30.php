<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-11-30 06:06:43 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-11-30 06:07:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:07:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:07:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:07:42 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:11:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:11:29 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:12:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:12:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:14:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:14:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:14:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:15:19 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:15:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:16:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:17:17 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:18:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:18:12 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:18:12 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:19:00 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:21:10 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:23:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:26:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:27:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:28:48 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:28:56 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:29:00 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:29:00 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:29:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:29:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:29:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:50:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:54:49 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 06:59:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:04:13 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:04:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:05:29 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:07:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:07:06 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-11-30 07:07:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 07:07:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 21:39:26 --> Severity: error --> Exception: Call to undefined method Activity_model::add() F:\xampp\htdocs\ozient\materialadmin\application\controllers\Auth.php 301
ERROR - 2019-11-30 10:45:09 --> Severity: Notice --> Undefined property: Profile::$activity_model F:\xampp\htdocs\ozient\materialadmin\application\controllers\admin\Profile.php 23
ERROR - 2019-11-30 10:45:09 --> Severity: error --> Exception: Call to a member function add() on null F:\xampp\htdocs\ozient\materialadmin\application\controllers\admin\Profile.php 23
ERROR - 2019-11-30 11:06:13 --> Query error: Table 'ci_material_admin.rci_usersole' doesn't exist - Invalid query: SELECT COUNT(*) as total_users
FROM `rci_usersole`
GROUP BY `role`
ERROR - 2019-11-30 11:06:13 --> Severity: error --> Exception: Call to a member function result_array() on boolean F:\xampp\htdocs\ozient\materialadmin\application\models\admin\Ci_example_model.php 163
ERROR - 2019-11-30 11:06:30 --> Query error: Table 'ci_material_admin.ci_usersole' doesn't exist - Invalid query: SELECT COUNT(*) as total_users
FROM `ci_usersole`
GROUP BY `role`
ERROR - 2019-11-30 11:06:30 --> Severity: error --> Exception: Call to a member function result_array() on boolean F:\xampp\htdocs\ozient\materialadmin\application\models\admin\Ci_example_model.php 163
ERROR - 2019-11-30 22:12:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:12:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:13:30 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:14:37 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:14:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:14:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:15:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:16:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:16:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:17:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:17:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:19:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:19:47 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:19:48 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:20:13 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:20:39 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:22:56 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:24:45 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:24:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:25:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:26:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:27:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:27:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:28:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:28:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:28:31 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:28:53 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:31:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:32:07 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 22:32:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:06:05 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:07:19 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:07:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:08:53 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:09:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:10:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:10:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:10:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:12:21 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:12:35 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:12:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:13:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:14:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:14:33 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:14:58 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:15:16 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:15:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:15:44 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:16:06 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:16:22 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:16:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:16:55 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:17:17 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:17:28 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:17:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:18:03 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:18:15 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:18:32 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:19:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:20:38 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:20:39 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:20:46 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:21:23 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:22:00 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:22:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:22:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:23:27 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:23:39 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:24:26 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:25:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:27:51 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:28:41 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:28:43 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:28:49 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:28:54 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:29:39 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:30:52 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:31:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:31:41 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:33:01 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:33:28 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:33:40 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:35:02 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:38:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 23:38:38 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 13:05:50 --> Query error: FUNCTION ci_users.MONTH does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT `ci_user_groups`.`group_name` as `label`, COUNT(*) as value, ci_users.MONTH(created_at) as month
FROM `ci_users`
JOIN `ci_user_groups` ON `ci_user_groups`.`id` = `ci_users`.`role`
GROUP BY `role`
ERROR - 2019-11-30 13:05:50 --> Severity: error --> Exception: Call to a member function result_array() on boolean F:\xampp\htdocs\ozient\materialadmin\application\models\admin\Ci_example_model.php 164
ERROR - 2019-11-30 13:06:14 --> Query error: FUNCTION ci_users.MONTH does not exist. Check the 'Function Name Parsing and Resolution' section in the Reference Manual - Invalid query: SELECT `ci_user_groups`.`group_name`, COUNT(*) as users, ci_users.MONTH(created_at) as month
FROM `ci_users`
JOIN `ci_user_groups` ON `ci_user_groups`.`id` = `ci_users`.`role`
GROUP BY `role`, MONTH(created_at)
ERROR - 2019-11-30 13:06:14 --> Severity: error --> Exception: Call to a member function result_array() on boolean F:\xampp\htdocs\ozient\materialadmin\application\models\admin\Ci_example_model.php 173
ERROR - 2019-11-30 13:08:35 --> Severity: Notice --> Undefined variable: groups F:\xampp\htdocs\ozient\materialadmin\application\views\admin\ci_examples\charts.php 179
ERROR - 2019-11-30 13:44:24 --> Query error: Unknown column 'ci_user_groups.x' in 'field list' - Invalid query: SELECT `ci_user_groups`.`x`, COUNT(ci_users.role = "1") as y, COUNT(ci_users.role = "2") as z, COUNT(ci_users.role = "4") as a, MONTHNAME(created_at) as month
FROM `ci_users`
JOIN `ci_user_groups` ON `ci_user_groups`.`id` = `ci_users`.`role`
GROUP BY `role`, MONTH(created_at)
ORDER BY MONTH(created_at) ASC
ERROR - 2019-11-30 13:44:24 --> Severity: error --> Exception: Call to a member function result_array() on boolean F:\xampp\htdocs\ozient\materialadmin\application\models\admin\Ci_example_model.php 177
ERROR - 2019-11-30 20:13:13 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'codeldzi_classified'@'localhost' to database 'codeldzi_material_admin' /home/codeldzi/public_html/materialadmin/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-11-30 20:13:13 --> Unable to connect to the database
ERROR - 2019-11-30 20:13:14 --> Severity: Warning --> mysqli::real_connect(): (42000/1044): Access denied for user 'codeldzi_classified'@'localhost' to database 'codeldzi_material_admin' /home/codeldzi/public_html/materialadmin/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2019-11-30 20:13:14 --> Unable to connect to the database
ERROR - 2019-11-30 20:21:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-11-30 20:21:12 --> 404 Page Not Found: Public/favicon.ico
