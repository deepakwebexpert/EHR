<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/dist
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/dist
ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/dist
ERROR - 2018-01-15 08:27:58 --> 404 Page Not Found: Public/bootstrap
ERROR - 2018-01-15 08:27:59 --> 404 Page Not Found: Public/dist
ERROR - 2018-01-15 08:27:59 --> 404 Page Not Found: Public/dist
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 80
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 80
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 85
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 85
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(include/control_sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 106
ERROR - 2018-01-15 08:28:18 --> Severity: Warning --> include(): Failed opening 'include/control_sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 106
ERROR - 2018-01-15 08:28:18 --> 404 Page Not Found: Plugins/jquery
ERROR - 2018-01-15 08:28:18 --> 404 Page Not Found: admin/Faviconico/index
ERROR - 2018-01-15 08:28:52 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:33:01 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:33:01 --> 404 Page Not Found: Plugins/jquery
ERROR - 2018-01-15 08:33:04 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 48
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 48
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 53
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 53
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 57
ERROR - 2018-01-15 08:33:46 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 57
ERROR - 2018-01-15 08:33:46 --> 404 Page Not Found: Plugins/jquery
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 48
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 48
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 53
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 53
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 57
ERROR - 2018-01-15 08:33:47 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 57
ERROR - 2018-01-15 08:33:48 --> 404 Page Not Found: Plugins/jquery
ERROR - 2018-01-15 08:33:50 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:11 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:12 --> 404 Page Not Found: Plugins/jquery
ERROR - 2018-01-15 08:34:14 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:43 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:45 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 49
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 54
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:51 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 58
ERROR - 2018-01-15 08:34:54 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(include/navbar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 35
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(): Failed opening 'include/navbar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 35
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 40
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 40
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(include/sidebar.php): failed to open stream: No such file or directory C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 44
ERROR - 2018-01-15 08:35:21 --> Severity: Warning --> include(): Failed opening 'include/sidebar.php' for inclusion (include_path='.;C:\php\pear') C:\wamp64\www\codeigniter_adminlte\application\views\layout.php 44
ERROR - 2018-01-15 08:36:34 --> 404 Page Not Found: admin/Images/user.png
ERROR - 2018-01-15 08:36:34 --> 404 Page Not Found: admin/Images/user.png
ERROR - 2018-01-15 08:37:02 --> 404 Page Not Found: admin/Pages/widgets
ERROR - 2018-01-15 08:37:12 --> 404 Page Not Found: admin/Images/user.png
ERROR - 2018-01-15 08:37:13 --> 404 Page Not Found: admin/Images/user.png
ERROR - 2018-01-15 08:43:47 --> 404 Page Not Found: admin/Images/user.png
ERROR - 2018-01-15 08:46:44 --> 404 Page Not Found: admin/Pages/typography.html
ERROR - 2018-01-15 09:04:17 --> 404 Page Not Found: admin/Indexhtml/index
ERROR - 2018-01-15 09:43:04 --> 404 Page Not Found: admin/Pages/typography.html
