<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-27 08:04:37 --> 404 Page Not Found: admin/Ui/favicon.ico
ERROR - 2018-01-27 08:12:22 --> Severity: Notice --> Undefined property: Export::$ignore_directories C:\wamp64\www\ozi_admin\application\controllers\admin\Export.php 22
ERROR - 2018-01-27 08:12:22 --> Severity: Notice --> Only variables should be assigned by reference C:\wamp64\www\ozi_admin\application\controllers\admin\Export.php 28
ERROR - 2018-01-27 08:22:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:22:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:22:30 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:22:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:22:49 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:23:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:24:13 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:24:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:25:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:25:13 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:25:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:25:20 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:25:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY username asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY username asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY email asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY email asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:26:34 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:26:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY email asc LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY email asc LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:27:18 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:18 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:18 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 45
ERROR - 2018-01-27 08:27:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY   LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY   LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:27:19 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:27:23 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:23 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:23 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 45
ERROR - 2018-01-27 08:27:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY   LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY   LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:27:47 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:47 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:47 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 45
ERROR - 2018-01-27 08:27:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY   LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY   LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:27:48 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:27:52 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:52 --> Severity: Notice --> Undefined index:  C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 44
ERROR - 2018-01-27 08:27:52 --> Severity: Notice --> Undefined index: order C:\wamp64\www\ozi_admin\application\libraries\Datatable.php 45
ERROR - 2018-01-27 08:27:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'ORDER BY   LIMIT 10 OFFSET 0' at line 1 - Invalid query: SELECT * FROM ci_users WHERE (  is_admin = 0 ) ORDER BY created_at ORDER BY   LIMIT 10 OFFSET 0 
ERROR - 2018-01-27 08:32:13 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:32:56 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:33:14 --> 404 Page Not Found: admin/Users/favicon.ico
ERROR - 2018-01-27 08:33:15 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:35:09 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:35:37 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:36:35 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:36:52 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:46:14 --> 404 Page Not Found: admin/Group/favicon.ico
ERROR - 2018-01-27 08:49:32 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:54:53 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:57:29 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:57:50 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 08:57:53 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:01:54 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:05:06 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:05:26 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:42:13 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:42:39 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:54:45 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 09:55:52 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:28:28 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:28:52 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:53 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:53 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:54 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:54 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:54 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:56 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:57 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:57 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:58 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:58 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:58 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:58 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:28:59 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:00 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:00 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:00 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:00 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:00 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:01 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:02 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:02 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:03 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:04 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:04 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:05 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:26 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:27 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:27 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:27 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:27 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:27 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:45 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:45 --> 404 Page Not Found: Public/css
ERROR - 2018-01-27 11:29:47 --> 404 Page Not Found: Public/pimages
ERROR - 2018-01-27 11:29:47 --> 404 Page Not Found: Public/puimages
ERROR - 2018-01-27 11:29:47 --> 404 Page Not Found: Public/pubimages
ERROR - 2018-01-27 11:29:48 --> 404 Page Not Found: Public/publimages
ERROR - 2018-01-27 11:29:48 --> 404 Page Not Found: Public/publiimages
ERROR - 2018-01-27 11:29:48 --> 404 Page Not Found: Public/publicimages
ERROR - 2018-01-27 11:29:49 --> 404 Page Not Found: Public/public
ERROR - 2018-01-27 11:29:56 --> 404 Page Not Found: Public/publi
ERROR - 2018-01-27 11:29:56 --> 404 Page Not Found: Public/publ
ERROR - 2018-01-27 11:29:56 --> 404 Page Not Found: Public/pub
ERROR - 2018-01-27 11:29:57 --> 404 Page Not Found: Public/pu
ERROR - 2018-01-27 11:29:57 --> 404 Page Not Found: Public/p
ERROR - 2018-01-27 11:33:12 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-01-27 11:33:16 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:33:30 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:34:26 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:35:38 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-27 11:36:22 --> 404 Page Not Found: admin/Faviconico/index
ERROR - 2018-01-27 12:05:10 --> 404 Page Not Found: admin/Ui/favicon.ico
