<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-03 06:12:21 --> 404 Page Not Found: Dashboard/index
ERROR - 2017-10-03 06:12:43 --> 404 Page Not Found: Dashboard/index
ERROR - 2017-10-03 06:19:36 --> Severity: Notice --> Undefined index: username C:\wamp64\www\codeigniter_user_management\application\models\admin\Auth_model.php 5
ERROR - 2017-10-03 07:13:03 --> 404 Page Not Found: admin/Adminlte_documentation/index.html
ERROR - 2017-10-03 07:13:10 --> 404 Page Not Found: admin/Adminlte_documentation/index.html
ERROR - 2017-10-03 07:13:16 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:16 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:16 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:49 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:49 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:49 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:13:56 --> 404 Page Not Found: admin/Adminlte_documentation/index.html
ERROR - 2017-10-03 07:14:21 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:21 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:21 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:28 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:28 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:28 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:14:32 --> 404 Page Not Found: Index2html/index
ERROR - 2017-10-03 07:15:37 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:15:37 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:15:37 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:15:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:15:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 07:15:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 17:25:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/codeglamour/ci_lte/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2017-10-03 17:25:54 --> Unable to connect to the database
ERROR - 2017-10-03 17:29:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/codeglamour/ci_lte/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2017-10-03 17:29:17 --> Unable to connect to the database
ERROR - 2017-10-03 17:29:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) /var/www/html/codeglamour/ci_lte/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2017-10-03 17:29:20 --> Unable to connect to the database
ERROR - 2017-10-03 18:09:55 --> 404 Page Not Found: Ci_lte/adminlte_documentation
ERROR - 2017-10-03 18:10:44 --> 404 Page Not Found: Ci_lte/adminlte_documentation
ERROR - 2017-10-03 18:12:08 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 18:12:09 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-03 18:12:09 --> 404 Page Not Found: Dist/img
