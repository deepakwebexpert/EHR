<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 17:19:37 --> 404 Page Not Found: Public/favicon.ico
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-16 17:19:37 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-04-16 17:26:43 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-16 17:28:39 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-16 17:30:30 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-16 17:40:43 --> Severity: error --> Exception: syntax error, unexpected '$query' (T_VARIABLE) C:\wamp64\www\ci_material_admin\application\models\admin\User_model.php 29
ERROR - 2018-04-16 17:41:03 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\ci_material_admin\application\models\admin\User_model.php 44
ERROR - 2018-04-16 17:41:08 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\ci_material_admin\application\models\admin\User_model.php 44
ERROR - 2018-04-16 17:41:33 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE) C:\wamp64\www\ci_material_admin\application\models\admin\User_model.php 44
