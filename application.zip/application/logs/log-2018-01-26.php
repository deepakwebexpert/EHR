<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-01-26 14:44:45 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-01-26 14:45:01 --> 404 Page Not Found: admin/Faviconico/index
ERROR - 2018-01-26 14:45:14 --> 404 Page Not Found: admin/Ci_examples/favicon.ico
ERROR - 2018-01-26 14:45:29 --> 404 Page Not Found: admin/Auth/favicon.ico
ERROR - 2018-01-26 15:01:12 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-01-26 15:01:19 --> 404 Page Not Found: admin/Faviconico/index
ERROR - 2018-01-26 15:01:37 --> 404 Page Not Found: Public/plugins
ERROR - 2018-01-26 16:56:41 --> 404 Page Not Found: admin/Ci_examples/favicon.ico
ERROR - 2018-01-26 19:01:37 --> 404 Page Not Found: admin/Charts/favicon.ico
ERROR - 2018-01-26 19:02:15 --> 404 Page Not Found: admin/Ui/favicon.ico
ERROR - 2018-01-26 19:02:55 --> 404 Page Not Found: admin/Widgets/favicon.ico
ERROR - 2018-01-26 19:03:15 --> 404 Page Not Found: admin/Widgets/favicon.ico
ERROR - 2018-01-26 19:25:28 --> 404 Page Not Found: admin/Users/favicon.ico
