<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-18 07:11:20 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-04-18 07:13:54 --> 404 Page Not Found: admin/Auth/login
ERROR - 2018-04-18 07:14:10 --> 404 Page Not Found: admin/Auth/login
ERROR - 2018-04-18 07:14:16 --> 404 Page Not Found: admin/Auth/login
ERROR - 2018-04-18 07:20:35 --> 404 Page Not Found: admin/Auth/login
ERROR - 2018-04-18 07:22:29 --> 404 Page Not Found: admin/Auth/login
ERROR - 2018-04-18 07:22:54 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-04-18 07:49:07 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-18 07:50:01 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 07:50:20 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 07:51:09 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-04-18 07:51:46 --> 404 Page Not Found: Dashboard/index
ERROR - 2018-04-18 07:56:55 --> 404 Page Not Found: admin/Auth/profile
ERROR - 2018-04-18 07:57:01 --> 404 Page Not Found: admin/Auth/profile
ERROR - 2018-04-18 07:59:35 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-18 07:59:57 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-18 08:09:34 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:10:30 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:11:12 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:11:19 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:11:25 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:11:29 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:15:04 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-18 08:40:09 --> 404 Page Not Found: admin/Auth/profile
ERROR - 2018-04-18 08:41:15 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:41:32 --> Query error: Table 'ci_material_admin_db.hs_clients' doesn't exist - Invalid query: SELECT *
FROM `hs_clients`
WHERE `email` = 'nauman_wwe@yahoo.com'
 LIMIT 1
ERROR - 2018-04-18 08:41:32 --> Severity: error --> Exception: Call to a member function num_rows() on boolean C:\wamp64\www\ci_material_admin\system\libraries\Form_validation.php 1122
ERROR - 2018-04-18 08:42:52 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:43:03 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:43:30 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:43:53 --> Severity: Notice --> Undefined property: Auth::$mailer C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 91
ERROR - 2018-04-18 08:43:53 --> Severity: error --> Exception: Call to a member function Tpl_Registration() on null C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 91
ERROR - 2018-04-18 08:50:53 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:51:13 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:51:49 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 08:59:01 --> Severity: Warning --> fsockopen(): SSL operation failed with code 1. OpenSSL Error messages:
error:14090086:SSL routines:ssl3_get_server_certificate:certificate verify failed C:\wamp64\www\ci_material_admin\system\libraries\Email.php 2055
ERROR - 2018-04-18 08:59:01 --> Severity: Warning --> fsockopen(): Failed to enable crypto C:\wamp64\www\ci_material_admin\system\libraries\Email.php 2055
ERROR - 2018-04-18 08:59:01 --> Severity: Warning --> fsockopen(): unable to connect to ssl://smtp.googlemail.com:465 (Unknown error) C:\wamp64\www\ci_material_admin\system\libraries\Email.php 2055
ERROR - 2018-04-18 09:01:58 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 09:02:19 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 09:03:28 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-18 09:48:43 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 57
ERROR - 2018-04-18 09:49:24 --> Severity: error --> Exception: syntax error, unexpected '{', expecting '(' C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 48
ERROR - 2018-04-18 09:49:43 --> Severity: error --> Exception: syntax error, unexpected '{', expecting '(' C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 48
ERROR - 2018-04-18 09:55:06 --> Severity: error --> Exception: syntax error, unexpected '{', expecting '(' C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 48
ERROR - 2018-04-18 09:55:10 --> Severity: error --> Exception: syntax error, unexpected '{', expecting '(' C:\wamp64\www\ci_material_admin\application\controllers\Auth.php 48
ERROR - 2018-04-18 10:22:59 --> 404 Page Not Found: user/Dashboard/index
ERROR - 2018-04-18 10:23:40 --> 404 Page Not Found: user/Dashboard/index
ERROR - 2018-04-18 10:41:11 --> 404 Page Not Found: user/Dashboard/index
