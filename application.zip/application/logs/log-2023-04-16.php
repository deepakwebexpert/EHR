<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:42:16 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 19:44:01 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 19:44:42 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 19:44:47 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 21
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 21
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 32
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 32
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 33
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 33
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 34
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 34
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 35
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 35
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 49
ERROR - 2023-04-16 19:45:20 --> Severity: 8192 --> explode(): Passing null to parameter #2 ($string) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 49
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 52
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 52
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 69
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 82
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 95
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 110
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 110
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 127
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 139
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 152
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 165
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 177
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 184
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 185
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 196
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 209
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 223
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 239
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 240
ERROR - 2023-04-16 19:45:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\user_edit.php 241
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 297
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 21
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 21
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 35
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 35
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 49
ERROR - 2023-04-16 19:46:12 --> Severity: 8192 --> explode(): Passing null to parameter #2 ($string) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 49
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\department.php 52
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 52
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 69
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 82
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 95
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\department.php 110
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 110
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 127
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 139
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 152
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 165
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 177
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 184
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 185
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 196
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 209
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 223
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 239
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 240
ERROR - 2023-04-16 19:46:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 241
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 21
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 21
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\jeol\application\views\admin\users\department.php 35
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 35
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 49
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 49
ERROR - 2023-04-16 19:47:57 --> Severity: 8192 --> explode(): Passing null to parameter #2 ($string) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 49
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\department.php 52
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 52
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 69
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 69
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 82
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 82
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 95
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 95
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\department.php 110
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 110
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 127
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 127
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 139
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 139
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 152
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 152
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 165
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 165
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 177
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 177
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 184
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 184
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 185
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 185
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 196
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 196
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 209
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 209
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 223
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 223
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 239
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 239
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 240
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 240
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Undefined variable $employee_data C:\xampp\htdocs\jeol\application\views\admin\users\department.php 241
ERROR - 2023-04-16 19:47:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\users\department.php 241
ERROR - 2023-04-16 19:48:23 --> Severity: 8192 --> ctype_digit(): Argument of type null will be interpreted as string in the future C:\xampp\htdocs\jeol\system\libraries\Pagination.php 522
ERROR - 2023-04-16 19:48:25 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 19:49:01 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:32 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:35 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:57 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:49:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:50:11 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:50:11 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 39
ERROR - 2023-04-16 19:50:41 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 28
ERROR - 2023-04-16 19:50:41 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 28
ERROR - 2023-04-16 19:50:53 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 28
ERROR - 2023-04-16 19:50:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 28
ERROR - 2023-04-16 19:51:35 --> Severity: Warning --> Undefined variable $all_users C:\xampp\htdocs\jeol\application\views\admin\users\department.php 26
ERROR - 2023-04-16 19:51:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\department.php 26
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:52 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "username" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 29
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:51:53 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "email" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:24 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "group" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 30
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:42 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:54 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "mobile_no" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:52:55 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "created_at" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\xampp\htdocs\jeol\application\views\admin\users\department.php 32
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:11 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "role" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\helpers\data_helper.php 7
ERROR - 2023-04-16 19:53:20 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 34
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:29 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 33
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:39 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:53:41 --> Severity: Warning --> Undefined array key "is_active" C:\xampp\htdocs\jeol\application\views\admin\users\department.php 31
ERROR - 2023-04-16 19:59:32 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 20:00:59 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:00:59 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:16 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:27 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:36 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:01:36 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 27
ERROR - 2023-04-16 20:02:06 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:06 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:06 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:17 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:17 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:30 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:30 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:45 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:45 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:45 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:51 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:02:51 --> Severity: Warning --> Undefined variable $designation C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:02:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 116
ERROR - 2023-04-16 20:03:13 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:03:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\users\add_department.php 58
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:03 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: Warning --> Undefined array key "is_admin" C:\xampp\htdocs\jeol\application\controllers\admin\Users.php 40
ERROR - 2023-04-16 20:56:09 --> Severity: 8192 --> str_replace(): Passing null to parameter #3 ($subject) of type array|string is deprecated C:\xampp\htdocs\jeol\system\core\Output.php 457
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:05:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:14:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 39
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 54
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 55
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:15:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\department\add_department.php 56
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 54
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 54
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 55
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 55
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 56
ERROR - 2023-04-16 21:15:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 56
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 54
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 54
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 55
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 55
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 56
ERROR - 2023-04-16 21:16:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 56
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:17:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:18:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:19:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Undefined variable $department C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:20:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:21:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:22:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 28
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 29
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 30
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 34
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined variable $desc C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 36
ERROR - 2023-04-16 21:22:04 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 37
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 28
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 29
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined array key "description" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 30
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 34
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined variable $desc C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 36
ERROR - 2023-04-16 21:22:51 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 37
ERROR - 2023-04-16 21:23:15 --> Severity: Warning --> Undefined variable $desc C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 33
ERROR - 2023-04-16 21:23:15 --> Severity: Warning --> Undefined array key "status" C:\xampp\htdocs\jeol\application\views\admin\customer\customer.php 34
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:31:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:36:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:37:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:38:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:38:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:50:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:51:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 21:51:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:06:41 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:06 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:17 --> Severity: Warning --> Undefined array key "contatc_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "contact_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "contact_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "contact_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "cust_depart" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 38
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "end_user_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 39
ERROR - 2023-04-16 22:07:26 --> Severity: Warning --> Undefined array key "contact_no" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 40
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 22:11:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:12:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:14:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:14:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 39
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 52
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:18:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 66
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:19:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:19:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Undefined variable $reporting_employees C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 41
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:19:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined array key "emp_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined array key "emp_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined array key "emp_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined array key "emp_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:20:57 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:21:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 57
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 70
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:21:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 84
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:21:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:22:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:23:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:24:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:24:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:25:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:25:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:26:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:27:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:28:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:30:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:30:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:31:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:32:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:32:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:34:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:34:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:13 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:35:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:35:13 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:24 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:35:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:44:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:44:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 39
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 52
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Undefined variable $customer C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 22:44:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_customer.php 66
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 23:01:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 42
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 75
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 88
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 102
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 115
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 128
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Undefined variable $customer_dept C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 23:02:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 141
ERROR - 2023-04-16 23:05:04 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:04 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:04 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:04 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:04 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:18 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:18 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:18 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:18 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:18 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:19 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:19 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:19 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:19 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:19 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:58 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:58 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:58 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:58 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:05:58 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:06:21 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:06:21 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:06:21 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:06:21 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:06:21 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:07 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:07 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:07 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:07 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:07 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:13 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:13:13 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:13:15 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:15 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:15 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:15 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:13:15 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\add_department.php 60
ERROR - 2023-04-16 23:14:22 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:14:22 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:44:29 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:44:29 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:46:02 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:46:02 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:46:34 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:46:34 --> Severity: Warning --> Undefined array key "cust_name" C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:08 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:09 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:29 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
ERROR - 2023-04-16 23:47:31 --> Severity: Warning --> Attempt to read property "cust_name" on null C:\xampp\htdocs\jeol\application\views\admin\customer\department.php 37
