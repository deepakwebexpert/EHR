<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-21 05:52:34 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-04-21 05:58:13 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2018-04-21 06:03:17 --> 404 Page Not Found: Public/favicon.ico
