<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-02-07 06:26:36 --> 404 Page Not Found: Public/favicon.ico
