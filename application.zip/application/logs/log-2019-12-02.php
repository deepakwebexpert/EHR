<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-12-02 00:18:18 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 00:18:36 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:19:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:19:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:20:33 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 00:21:18 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:21:24 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:21:34 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:22:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:22:14 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:22:25 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:22:41 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:23:11 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:23:41 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 00:24:20 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:24:40 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 00:25:57 --> 404 Page Not Found: Public/plugins
ERROR - 2019-12-02 00:28:35 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 02:06:01 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 02:06:24 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 04:45:07 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 11:07:25 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:00:18 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:08:44 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:08:50 --> Severity: error --> Exception: Call to undefined method Auth_model::check_recaptcha_status() /home/codeldzi/public_html/materialadmin/application/controllers/Auth.php 30
ERROR - 2019-12-02 14:09:27 --> Severity: error --> Exception: Call to undefined method Auth::recaptcha_verify_request() /home/codeldzi/public_html/materialadmin/application/controllers/Auth.php 31
ERROR - 2019-12-02 14:10:04 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:11:29 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:13:21 --> 404 Page Not Found: Public/favicon.ico
ERROR - 2019-12-02 14:16:32 --> Severity: Notice --> Undefined property: CI_Loader::$_siteKey /home/codeldzi/public_html/materialadmin/application/views/auth/login.php 82
