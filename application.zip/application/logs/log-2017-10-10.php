<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-10 16:26:18 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-10 16:28:11 --> 404 Page Not Found: Adminlte_documentation/index.html
ERROR - 2017-10-10 16:29:13 --> 404 Page Not Found: Adminlte_documentation/index.html
ERROR - 2017-10-10 16:30:24 --> 404 Page Not Found: Adminlte_documentation/index.html
ERROR - 2017-10-10 16:30:29 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-10 16:30:29 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-10 16:30:29 --> 404 Page Not Found: Dist/img
ERROR - 2017-10-10 16:32:11 --> 404 Page Not Found: Dist/img
