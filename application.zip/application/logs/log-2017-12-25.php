<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-12-25 17:09:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) C:\wamp64\www\codeigniter_adminlte\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2017-12-25 17:09:56 --> Unable to connect to the database
ERROR - 2017-12-25 17:42:44 --> 404 Page Not Found: Users/create_users_pdf
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Notice --> Undefined offset: 0 C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 82
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> preg_match() expects parameter 2 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Cell\DefaultValueBinder.php 88
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> mb_substr() expects parameter 1 to be string, array given C:\wamp64\www\codeigniter_adminlte\application\libraries\PHPExcel\Shared\String.php 581
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\codeigniter_adminlte\system\core\Exceptions.php:271) C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 176
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\codeigniter_adminlte\system\core\Exceptions.php:271) C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 177
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\codeigniter_adminlte\system\core\Exceptions.php:271) C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 178
ERROR - 2017-12-25 17:45:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\wamp64\www\codeigniter_adminlte\system\core\Exceptions.php:271) C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 180
ERROR - 2017-12-25 17:45:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 153
ERROR - 2017-12-25 17:45:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 161
ERROR - 2017-12-25 18:08:45 --> Severity: error --> Exception: syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\wamp64\www\codeigniter_adminlte\application\models\admin\User_model.php 17
ERROR - 2017-12-25 18:09:07 --> Severity: Notice --> Use of undefined constant ci_users - assumed 'ci_users' C:\wamp64\www\codeigniter_adminlte\application\models\admin\User_model.php 17
ERROR - 2017-12-25 18:36:20 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-12-25 18:36:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-12-25 18:36:50 --> 404 Page Not Found: Dist/img
ERROR - 2017-12-25 18:49:30 --> Query error: Table 'ci_adminlte_db.users' doesn't exist - Invalid query: SELECT *
FROM `users`
WHERE `email` = 'nauman_wwe@yahoo.com'
 LIMIT 1
ERROR - 2017-12-25 18:51:05 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-12-25 18:51:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-12-25 18:53:38 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_edit.php 75
ERROR - 2017-12-25 18:53:38 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_edit.php 75
ERROR - 2017-12-25 19:39:04 --> 404 Page Not Found: Export/index
ERROR - 2017-12-25 19:41:27 --> 404 Page Not Found: Export/index
ERROR - 2017-12-25 19:41:35 --> 404 Page Not Found: Export/dbexport
ERROR - 2017-12-25 19:42:11 --> Severity: Notice --> Undefined property: Export::$ignore_directories C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Export.php 22
ERROR - 2017-12-25 19:42:11 --> Severity: Notice --> Only variables should be assigned by reference C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Export.php 28
