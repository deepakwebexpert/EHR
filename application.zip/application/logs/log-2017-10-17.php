<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-10-17 08:49:05 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:49:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:52:34 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:52:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:52:36 --> Severity: Notice --> Undefined variable: user_groups C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:52:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\wamp64\www\codeigniter_adminlte\application\views\admin\users\user_add.php 71
ERROR - 2017-10-17 08:53:56 --> Severity: Error --> Call to undefined method User_model::get_user_groups() C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Users.php 53
ERROR - 2017-10-17 09:52:44 --> Severity: Error --> Call to undefined method Auth_model::get_admin_detail() C:\wamp64\www\codeigniter_adminlte\application\controllers\admin\Auth.php 74
ERROR - 2017-10-17 09:57:21 --> Severity: Notice --> Undefined variable: admin C:\wamp64\www\codeigniter_adminlte\application\views\admin\auth\profile.php 16
ERROR - 2017-10-17 09:57:21 --> Severity: Notice --> Undefined variable: admin C:\wamp64\www\codeigniter_adminlte\application\views\admin\auth\profile.php 23
ERROR - 2017-10-17 09:57:21 --> Severity: Notice --> Undefined variable: admin C:\wamp64\www\codeigniter_adminlte\application\views\admin\auth\profile.php 31
ERROR - 2017-10-17 09:57:21 --> Severity: Notice --> Undefined variable: admin C:\wamp64\www\codeigniter_adminlte\application\views\admin\auth\profile.php 39
ERROR - 2017-10-17 09:57:21 --> Severity: Notice --> Undefined variable: admin C:\wamp64\www\codeigniter_adminlte\application\views\admin\auth\profile.php 46
ERROR - 2017-10-17 10:12:34 --> 404 Page Not Found: admin/Groups/index
