<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-20 07:18:04 --> 404 Page Not Found: Auth/forgot-password
ERROR - 2018-04-20 07:18:36 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-20 07:18:43 --> 404 Page Not Found: Auth/forgot-password
ERROR - 2018-04-20 07:20:06 --> 404 Page Not Found: Public/plugins
ERROR - 2018-04-20 07:24:23 --> 404 Page Not Found: Auth/forgot-password
ERROR - 2018-04-20 07:24:37 --> 404 Page Not Found: Auth/forgot-password
ERROR - 2018-04-20 07:24:44 --> 404 Page Not Found: Auth/forgot-password
ERROR - 2018-04-20 07:25:27 --> Query error: Unknown column 'password_reset_code' in 'field list' - Invalid query: UPDATE `ci_users` SET `password_reset_code` = 'dd2dde535d322743ac08d65bf6df132d'
WHERE `id` = '35'
ERROR - 2018-04-20 07:27:31 --> Query error: Unknown column 'password_reset_code' in 'field list' - Invalid query: UPDATE `ci_users` SET `password_reset_code` = '2047faa23a3afb0518e063b768386764'
WHERE `id` = '35'
ERROR - 2018-04-20 07:28:31 --> Query error: Unknown column 'password_reset_code' in 'field list' - Invalid query: UPDATE `ci_users` SET `password_reset_code` = '5cf7077f388ad768bef26ebab21d821c'
WHERE `id` = '35'
ERROR - 2018-04-20 07:29:53 --> Query error: Unknown column 'password_reset_code' in 'where clause' - Invalid query: SELECT *
FROM `ci_users`
WHERE `password_reset_code` = '5cf7077f388ad768bef26ebab21d821c'
ERROR - 2018-04-20 07:29:53 --> Severity: error --> Exception: Call to a member function num_rows() on boolean /var/www/html/codeglamour_scripts/ci_material_admin/application/models/Auth_model.php 65
ERROR - 2018-04-20 07:37:25 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-20 07:42:21 --> 404 Page Not Found: Client/auth
ERROR - 2018-04-20 07:45:01 --> 404 Page Not Found: Client/auth
