<div class="row clearfix">
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
    <div class="card">
      <div class="header">
        <h2>
          DATABASE BACKUP
        </h2>
      </div>
      <div class="body">
        <div class="row clearfix">
          <div class="col-md-12">
          	<a href="<?= base_url('admin/export/dbexport'); ?>" class="btn bg-green"><i class="material-icons">cloud_download</i> &nbsp; Download & Create Backup</a>
          </div>
      </div>
  </div>
</div>
